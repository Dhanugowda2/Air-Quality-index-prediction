# Air Pollution Indicator

## Live at :
**https://Shashank-Salian.github.io/AirPollutionIndicator/**

<p align="center">
	Plant more <img src="/images/tree.svg" width="35" height="35" />
</p>